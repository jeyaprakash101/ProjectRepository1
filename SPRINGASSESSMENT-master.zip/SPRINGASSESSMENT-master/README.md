#SPRINGASSIGNMENT

http://www.journaldev.com/2583/spring-aop-example-tutorial-aspect-advice-pointcut-joinpoint-annotations

# SPRINGASSESSMENT
MovieRateController.java:


package com.inautix.XBBNHBS.ServletController;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inautix.XBBNHBS.MovieRate.MovieRateBean;
import com.inautix.XBBNHBS.MovieRate.MovieRateDao;

@RestController
@RequestMapping(value = "/movieRatings")
public class MovieRateController {

	@Autowired
	MovieRateDao movieRateDao;

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<MovieRateBean> getRatings() throws ClassNotFoundException {
		ArrayList<MovieRateBean> movieRatings = (ArrayList<MovieRateBean>) movieRateDao
				.getRatings();
		return movieRatings;
	}

	@RequestMapping(value = "/all/{phonenumber}", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<MovieRateBean> getRatings(@PathVariable("phonenumber") String phonenumber) {
		ArrayList<MovieRateBean> movieRatings = (ArrayList<MovieRateBean>) movieRateDao
				.getRatings(phonenumber);
		return movieRatings;
	}

	@RequestMapping(value = "/insert", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = { MediaType.APPLICATION_JSON_VALUE })
	public void addRating(@RequestBody MovieRateBean movieRateBean) {
		try {

			movieRateDao.insertRatings(movieRateBean);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/edit", method= RequestMethod.PUT)
	public void updateRating(@RequestBody MovieRateBean movieRateBean){
		try {

			movieRateDao.updateRatings(movieRateBean);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/delete/{movieName}/{phonenumber}", method=RequestMethod.DELETE)
	public int deleteRating(@PathVariable("movieName") String movieName, @PathVariable("phonenumber") String phonenumber){
		int numRows = 0;
		try {
			numRows = movieRateDao.deleteRatings(movieName, phonenumber);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return numRows;
	}
}


MovieRateDao.java:
package com.inautix.XBBNHBS.MovieRate;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.inautix.XBBNHBS.Movies.MovieDao;
import com.inautix.XBBNHBS.RowMapper.GetRatingsRowMapper;
import com.inautix.XBBNHBS.RowMapper.GetSpecificRatingsRowMapper;



@Repository
public class MovieRateDao extends JdbcDaoSupport{
	
	@Autowired
	public MovieRateDao(DataSource dataSource){
		setDataSource(dataSource);
	}
	
	public List<MovieRateBean> getRatings() throws ClassNotFoundException {
		// TODO Auto-generated method stub
		List<MovieRateBean> ratingsList = new ArrayList<MovieRateBean>();
		
		ratingsList = getJdbcTemplate().query("Select * from T_XBBNHBS_Ratings", new Object[]{}, new GetRatingsRowMapper());
		return ratingsList;
	}
	
	public List<MovieRateBean> getRatings(String phonenumber){
		List<MovieRateBean> ratingsList = new ArrayList<MovieRateBean>();
		ratingsList = getJdbcTemplate().query("Select * from T_XBBNHBS_Ratings where phonenumber = ?", new Object[]{phonenumber}, new GetSpecificRatingsRowMapper());
		return ratingsList;
	}
	
	public MovieRateBean insertRatings(MovieRateBean movieRateBean) throws ClassNotFoundException  {
		// TODO Auto-generated method stub
		int numRows = 0 ;
		MovieDao movieDao = new MovieDao();
		int movieId = movieDao.getMovieId(movieRateBean.getMovieName());
		int[] types={Types.INTEGER, Types.INTEGER, Types.VARCHAR};
		Object[] param={movieId, movieRateBean.getMovieRate(), movieRateBean.getPhonenumber()};
		numRows = getJdbcTemplate().update("insert into T_XBBNHBS_Ratings values(?,?,?)", param, types);
		return (numRows == 1 ? movieRateBean : null);
	}
	
	public MovieRateBean updateRatings(MovieRateBean movieRateBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		int numRows = 0 ;
		MovieDao movieDao = new MovieDao();
		int movieId = movieDao.getMovieId(movieRateBean.getMovieName());
		int[] types={Types.INTEGER, Types.VARCHAR, Types.INTEGER};
		Object[] param={movieRateBean.getMovieRate(), movieRateBean.getPhonenumber(), movieId};
		numRows = getJdbcTemplate().update("update T_XBBNHBS_Ratings set rating = ? where phonenumber = ? and movieId = ?", param, types);
		return (numRows == 1 ? movieRateBean : null);
	}
	
	public int deleteRatings(String movieName, String phonenumber) throws ClassNotFoundException{
		int numRows = 0;
		MovieDao movieDao = new MovieDao();
		int movieId = movieDao.getMovieId(movieName);
		numRows = getJdbcTemplate().update(
				"delete from T_XBBNHBS_Ratings where movieId=? and phonenumber = ?",
				new Object[] { movieId, phonenumber }, new int[] { Types.INTEGER, Types.VARCHAR });
		return numRows;
	}
}


GetRatingsRowMapper.java:
package com.inautix.XBBNHBS.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.inautix.XBBNHBS.MovieRate.MovieRateBean;
import com.inautix.XBBNHBS.Movies.MovieDao;

public class GetRatingsRowMapper implements RowMapper<MovieRateBean>{

	@Override
	public MovieRateBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		MovieRateBean movieRateBean = new MovieRateBean();
		MovieDao movieDao = new MovieDao();
		int movieId = rs.getInt(1);
		try {
			movieRateBean.setMovieName(movieDao.getMovieName(movieId));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		movieRateBean.setMovieRate(rs.getInt(2));
		movieRateBean.setPhonenumber(rs.getString(3));
		return movieRateBean;
	}
	 
}

MovieRateBean.java:
package com.inautix.XBBNHBS.MovieRate;

public class MovieRateBean {
	String movieName;
	String phonenumber;
     int movieRate;
	
	
	public int getMovieRate() {
		return movieRate;
	}
	
	public void setMovieRate(int movieRate) {
		this.movieRate = movieRate;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	
}
