package com.inautix.training.OnlineBanking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.training.OnlineBanking.domain.account;

public class manager {
private int managerId, managerPin;


public List getAllCustomer(){
	Connection con=null;
	List managerList = new ArrayList();
	account man = null;
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	}catch(ClassNotFoundException e) {
		System.out.println(e);
	}

	try {
		con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from cusdetails_xbbnhg4");
		
		while(rs.next()) {
			man = new account();
			man.setA_Id(rs.getString("cus_id"));
			man.setName(rs.getString("Cus_name"));
			man.setPan(rs.getString("cus_pan"));
			man.setEmailID(rs.getString("cus_emailid"));
			managerList.add(man);
		
		}
	
	 }
	catch(Exception e){
		
		
	}
	finally{
		try{
			
			con.close();
		}catch(Exception e){
			
		}
	}
		return 	managerList;
}

}
