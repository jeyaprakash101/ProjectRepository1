package com.inautix.training.OnlineBanking.dao;

public class prospect {

}
