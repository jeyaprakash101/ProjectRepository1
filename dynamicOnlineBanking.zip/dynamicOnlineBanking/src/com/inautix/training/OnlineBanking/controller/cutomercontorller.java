package com.inautix.training.OnlineBanking.controller;

import java.sql.SQLException;
import java.util.List;

import com.inautix.training.OnlineBanking.dao.customer;
import com.inautix.training.OnlineBanking.domain.account;



public class cutomercontorller {

	public void getAccountDetailsForCustomer(account acc) throws SQLException// it will be called from forum of the page.
	{
		customer customerDao = new customer();
		customerDao.createCustomer(acc);
	//	List customerAccountList =customerDao.getAccountDetailsForCustomer(customerId);
				
				
				//return customerAccountList;
	}
	public List  getCustomerDetails(String customerId)
	{
		System.out.println("Inside Controller block");
		customer customerDao = new customer();
		List customerAccountList =customerDao.getAccountDetailsForCustomer(customerId);
				
	//	Iterator itr = customerAccountList.iterator();
		return customerAccountList;
	}
}
