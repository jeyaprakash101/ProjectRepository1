package com.inautix.training.OnlineBanking.controller;

import java.util.List;

import com.inautix.training.OnlineBanking.dao.admin;

public class admincontorller {
	public List updateEmail(String cus_Email,String cus_Id)
	{
		admin dao=new admin();
		List li=dao.updateEmail(cus_Email,cus_Id);
		return li;
	}

}
