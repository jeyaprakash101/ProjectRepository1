package com.inautix.training.OnlineBanking.controller;

import java.util.List;

import com.inautix.training.OnlineBanking.dao.admin;
import com.inautix.training.OnlineBanking.dao.customer;
import com.inautix.training.OnlineBanking.exception.InsufficentBalanceException;

public class transfer {

	

public int transferamount(String youid,String cusid,int amount) throws InsufficentBalanceException 
{
int check,bal=0;
admin ad=new admin();
/*check=checkBalance(amount,youid);
if(check==0)
	System.out.println("");
else{
	
	 
}*/
bal=ad.transfer(youid,cusid,amount);
return bal;
}

	public void balance() {
		
		
	}
	public int checkBalance(int amount,String youid) throws InsufficentBalanceException
	{
		InsufficentBalanceException ibe=new InsufficentBalanceException();
		customer dao =new customer();
		int balance=dao.getbalance(youid);
		if(balance<amount)
		{
		return 0;
		}
		return 1;
	}
	
	
	

	

}
