package com.inautix.training.OnlineBanking.domain;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.inautix.training.OnlineBanking.controller.admincontorller;
import com.inautix.training.OnlineBanking.controller.cutomercontorller;
import com.inautix.training.OnlineBanking.controller.managercontorller;
import com.inautix.training.OnlineBanking.controller.transfer;
import com.inautix.training.OnlineBanking.domain.account;

public class banking {
	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		try
		{
			// inserting details by prospect
			String s;
			System.out.println("press key to continue 1.To Enter new customer");
			System.out.println("2.to view single customer details ");
			System.out.println("3.To view all customer details");
			System.out.println(" 4. To update Email ID of an Customer");
			System.out.println("5.To transfer amount");
			s=sc.nextLine();
			account acc=new account();
			cutomercontorller cus=new cutomercontorller();
			switch(s)
			{
				case "1": System.out.println("Enter the customer ID");
		String cusID= sc.nextLine();
		System.out.println("Enter the customer Name");
		String cusName=sc.nextLine();
		System.out.println("Enter the customer Pan ID");
		String cusPan=sc.nextLine();
		System.out.println("Enter the customer Email ID");
		String cusEmail=sc.nextLine();
		System.out.println("Enter the Password to be set(Please enter the password without any space)");
		String cusPassword=sc.next();
		
		acc.setA_Id(cusID);
		acc.setName(cusName);
		acc.setPan(cusPan);
		acc.setEmailID(cusEmail);
		acc.setPassword(cusPassword);
		cus.getAccountDetailsForCustomer(acc);break;
		// view a single customer details
				case "2":
		System.out.println("Enter customer Id: ");
		 String customerId=sc.nextLine();	
		 
		 List li= cus.getCustomerDetails(customerId);
		 Iterator itr = li.iterator();

		  while(itr.hasNext()){
			
			 acc = (account)itr.next();
			System.out.println("Account Number: "+acc.getA_Id());
		
			System.out.println("Name: "+acc.getName());
			System.out.println("Pan: "+acc.getPan());
			System.out.println("Email id: "+acc.getEmailID());
			
		  };break;
		  // view all customer details by manager
				case "3":managercontorller man=new managercontorller();
		  List customerList=man.getAllCustomers();
		  Iterator itr1=customerList.iterator();
		  while(itr1.hasNext())
		  {
				
			  acc=(account)itr1.next();
			  System.out.println("Customer name: "+acc.getName());
			  System.out.println("  Customer ID: "+acc.getA_Id());
			  System.out.println("    Customer PAN: "+acc.getPan());
			  System.out.println("      Customer Email ID: "+acc.getEmailID());
			  	
			  	
			  }break;
			  //to update customer email id by admin
				case "4":
					admincontorller ad=new admincontorller();
					System.out.println("enter the customer ID");
					String cus_Id=sc.nextLine();
					System.out.println("Enter the Email Id you want to correct");
					String cus_Email=sc.nextLine();
					List list=ad.updateEmail(cus_Email,cus_Id);
					 Iterator itr2=list.iterator();
					  while(itr2.hasNext())
					  {
							
						  acc=(account)itr2.next();
						  System.out.println("Customer name: "+acc.getName());
						  System.out.println("  Customer ID: "+acc.getA_Id());
						  System.out.println("    Customer PAN: "+acc.getPan());
						  System.out.println("      Customer Email ID: "+acc.getEmailID());
			};
			break;
				case "5":
					int bal;
					transfer tf=new transfer();
					System.out.println("eneter your customer ID");
					String youid=sc.nextLine();
					System.out.println("eneter the customer ID to which you want to transfer amount");
					String cuid=sc.nextLine();
					System.out.println("enter the amount to be transfered");
					int amount=sc.nextInt();
					 bal=tf.transferamount(youid,cuid,amount);
					System.out.println("your current balances="+bal);break;
				default:System.out.println("you have entered wrong option");
			
		
		}
		}catch(Exception e)
		{
			
		}
finally
{
	sc.close();
	System.out.println("Thank you for working with our banking System");
}

	}
	

	

}
