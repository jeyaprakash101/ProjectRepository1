package com.inautix.training.OnlineBanking.domain;

import com.inautix.training.OnlineBanking.exception.loginException;


public class account  
{
	 private int trAmount,balance;
	 private String Pan,EmailID,Password,Name,A_Id;
	public int getTrAmount() {
		return trAmount;
	}
	public void setTrAmount(int trAmount) {
		this.trAmount = trAmount;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getPan() {
		return Pan;
	}
	public void setPan(String pan) {
		Pan = pan;
	}
	public String getEmailID() {
		return EmailID;
	}
	public void setEmailID(String emailID) {
		EmailID = emailID;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getA_Id() {
		return A_Id;
	}
	public void setA_Id(String a_Id) {
		A_Id = a_Id;
	}

	
	/*public void invalidLogin() throws loginException
	{
		try
		{loginException lg=new loginException();
		throw lg;
		}
		catch(loginException l)
		{
			System.out.println("login exception:"+l);
		}
	}*/
}
