package com.inautix.training.OnlineBanking.exception;

public class InsufficentBalanceException extends Exception {
public String toString()
{
	return "Insufficent balance in your Account";
}
}
