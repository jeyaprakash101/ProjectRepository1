package com.inautix.training.OnlineBanking.exception;

public class loginException extends Exception{
public String toString()
{
	return "Login failed Please enter correct Username and Password";
}
}
