package ServletBanking;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.training.OnlineBanking.controller.managercontorller;
import com.inautix.training.OnlineBanking.domain.account;

/**
 * Servlet implementation class managerAllCus
 */
@WebServlet("/managerAllCus")
public class managerAllCus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public managerAllCus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		managercontorller man=new managercontorller();
		account acc=new account();
	  List customerList=man.getAllCustomers();
	  Iterator itr1=customerList.iterator();
	  while(itr1.hasNext())
	  {
			
		  acc=(account)itr1.next();
		  System.out.println("Customer name: "+acc.getName());
		  System.out.println("  Customer ID: "+acc.getA_Id());
		  System.out.println("    Customer PAN: "+acc.getPan());
		  System.out.println("      Customer Email ID: "+acc.getEmailID());
		  	
		  	
		  }
	  response.setContentType("text/html");
		response.sendRedirect("managerPage.html");
	  
	}

}
