package ServletBanking;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.training.OnlineBanking.controller.cutomercontorller;

import com.inautix.training.OnlineBanking.domain.account;

/**
 * Servlet implementation class managersingle
 */
@WebServlet("/managersingle")
public class managersingle extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public managersingle() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		cutomercontorller cus=new cutomercontorller();
		account acc=new account();
		 List li=  cus.getCustomerDetails(id);
		 Iterator itr = li.iterator();

		  while(itr.hasNext()){
			
			 acc = (account)itr.next();
			System.out.println("Account Number: "+acc.getA_Id());
		
			System.out.println("Name: "+acc.getName());
			System.out.println("Pan: "+acc.getPan());
			System.out.println("Email id: "+acc.getEmailID());
			
		  }
		  response.setContentType("text/html");
			response.sendRedirect("managerPage.html");
	}

}
