package ServletBanking;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.training.OnlineBanking.dao.loginValidation;
import com.inautix.training.OnlineBanking.domain.account;



/**
 * Servlet implementation class cusSignin
 */
@WebServlet("/cusSignin")
public class cusSignin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cusSignin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		account acc=new account();
		String name=request.getParameter("name");
		String pass=request.getParameter("pass");
		System.out.println("Account Id="+name);
		System.out.println("Account Password="+pass);
		loginValidation lv=new loginValidation();
		boolean result=lv.login(name,pass);
		if(result==true)
		{
			HttpSession session=request.getSession(true);
			session.setAttribute("name", acc.getA_Id());
			System.out.println("inside siginservlet authentiction passed "+acc.getA_Id());
			RequestDispatcher rd = request.getRequestDispatcher("/CustomerPage.html");
			rd.forward(request, response);
		
		}
	}

}
